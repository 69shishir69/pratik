from tkinter import *
from tkinter import messagebox
from PIL import ImageTk
import model.logindetails
import backend.dbconnect

class RegisterPage:
    """
    This class creates register window
    """
    def __init__(self,root):
        self.root = root
        self.root.title("Registration")
        self.root.geometry("1350x800+100+0")
        self.root.resizable(False, False)
        self.root.iconbitmap('E:\Softwarica\SEM 2\Introduction to algorithm\CW\submission\images\logo.ico')
        # Image
        self.bg = ImageTk.PhotoImage(file="E:\Softwarica\SEM 2\Introduction to algorithm\CW\submission\images\loginbg.jpg")
        self.bg_image = Label(self.root, image=self.bg).place(x=0, y=0,relwidth=1,relheight=1)

        self.db = backend.dbconnect.DBconnect()
        # Variables
        self.name = StringVar()
        self.studentid = StringVar()
        self.password = StringVar()
# ---------- Register Frame --------------------
        frame = Frame(self.root,bg='#161618')
        frame.place(x=450,y=290, height= 300 , width = 450)

# ----------- Labels --------------------------
        title = Label(self.root,text="Register Here",font=("Imapct", 35, "bold"), fg="#d77337", bg="#161618").place(x=520,y=220)
        # blank = Label(frame,text="     ",fg="#d77337").grid(row=0,column=0)
        username = Label(frame,text="Name:",font=("Goudy old style", 25, "bold"),
                            fg="gray", bg="#161618").grid(row=1,column=0,pady=10,sticky= E)
        studentid = Label(frame, text="Student ID:",font=("Goudy old style", 25, "bold"),
                     fg="gray", bg="#161618").grid(row=2, column=0, pady=10,sticky= E)
        password = Label(frame, text="Password:",font=("Goudy old style", 25, "bold"),
                     fg="gray", bg="#161618").grid(row=3, column=0, pady=10,sticky= E)

# -------------- Entry -----------------------
        self.txt_user = Entry(frame,textvariable=self.name, font=("Times new roman", 20), bg="lightgray")
        self.txt_user.grid(row=1,column=1,columnspan=3,sticky=W)

        self.txt_studentid = Entry(frame, textvariable=self.studentid, font=("Times new roman", 20), bg="lightgray")
        self.txt_studentid.grid(row=2, column=1, columnspan=3, sticky=W)

        self.txt_pass = Entry(frame, textvariable=self.password, font=("Times new roman", 20), bg="lightgray")
        self.txt_pass.grid(row=3, column=1, columnspan=3, sticky=W)

# ------------ Buttons -------------------------
        register_btn = Button(frame, text="Register", fg="white", bg="#d77337",
                              font=("Times new roman", 20), command=self.register_button).place(x=100, y=200,width=150, height=40)

        reset_btn = Button(frame, text="Reset", fg="white", bg="#d77337", \
                           font=("Imapct", 20), command=self.reset).place(x=275, y=200, width=150, height=40)


    def register_button(self):
        """
        This method adds the username, password and student id into the database
        :return:
        """
        username = self.txt_user.get()
        password = self.txt_pass.get()
        studentid = self.txt_studentid.get()

        if username == "" or password == "" or studentid =="":
            messagebox.showerror("Error", "Please provide your both username and password", parent=self.root)
        else:
            l = model.logindetails.RegisterDetails(username,password,studentid)
            query = 'insert into login_details(username,password,ID) values(%s,%s,%s)'
            values = (l.get_username(),l.get_password(),l.get_studentid())
            self.db.insert(query,values)
            messagebox.showinfo('Success','Registered,You Can Login Now!')
            self.root.destroy()

    def reset(self):
        """
        This method resets Entry Fields
        :return:
        """
        self.name.set("")
        self.studentid.set("")
        self.password.set("")

# root = Tk()
# obj = RegisterPage(root)
# root.mainloop()
#




