from tkinter import *
from PIL import ImageTk
from tkinter import messagebox
import backend.dbconnect
import model.logindetails
import frontend.MainDashboard
import frontend.register


class Login:
    """
    This class creates login window
    """
    def __init__(self, root):
        self.root = root
        self.root.title("Hostel Login")
        self.root.geometry("1350x800+100+0")
        self.root.resizable(False, False)
        self.root.iconbitmap('images\\logo.ico')
        # Image
        self.bg = ImageTk.PhotoImage(
            file="E:\Softwarica\SEM 2\Introduction to algorithm\CW\submission\images\loginbg.jpg")
        self.bg_image = Label(self.root, image=self.bg).place(x=0, y=0, relwidth=1, relheight=1)
        self.login_frame = ImageTk.PhotoImage(
            file="E:\Softwarica\SEM 2\Introduction to algorithm\CW\submission\images\loginframe.png")
        self.db = backend.dbconnect.DBconnect()

        # Text Variables
        self.username = StringVar()
        self.password = StringVar()

        # Login Frame
        Frame_login = Frame(self.root, bg='#161618')
        Frame_login.place(x=450, y=250, height=300, width=450)

        # loginfrm = Label(Frame_login, image=self.login_frame, bd=0, bg='#2c3033')
        # loginfrm.image = self.login_frame
        # loginfrm.place(x=0, y=0)

        title = Label(Frame_login, text="Login", font=("Imapct", 35, "bold"), fg="#d77337", bg="#161618").place(x=165,
                                                                                                                y=30)
        description = Label(Frame_login, text="Hostel Admin and Student Login", font=("Goudy old style", 15, "bold"),
                            fg="#d25d17", bg="#161618").place(x=110, y=88)
        user_lbl = Label(Frame_login, text="Username:", font=("Goudy old style", 15, "bold"),
                         fg="gray", bg="#161618").place(x=20, y=140)
        pass_lbl = Label(Frame_login, text="Password:", font=("Goudy old style", 15, "bold"),
                         fg="gray", bg="#161618").place(x=20, y=200)

        self.txt_user = Entry(Frame_login, textvariable=self.username, font=("Times new roman", 15), bg="lightgray")
        self.txt_user.place(x=120, y=140, width=300, height=35)

        self.txt_pass = Entry(Frame_login, textvariable=self.password, font=("Times new roman", 15), bg="lightgray")
        self.txt_pass.place(x=120, y=200, width=300, height=35)

        register_btn = Button(self.root, text="Register?", bd=0, bg="#161618", fg="#d77337",
                              font=("Times new roman", 12), activebackground="white",
                              command=self.register_button).place(x=865, y=550)

        login_btn = Button(Frame_login, text="Login", fg="white", bg="#d77337", \
                           font=("Imapct", 20), activebackground="white", command=self.login_button).place(x=120, y=250,
                                                                                                           width=150,
                                                                                                           height=40)

        reset_btn = Button(Frame_login, text="Reset", fg="white", bg="#d77337", \
                           font=("Imapct", 20), command=self.reset_button).place(x=275, y=250, width=150, height=40)

    def login_button(self):
        """
        This method checks for the registered username and password and opens Main Dashboard
        :return:
        """
        username = self.txt_user.get()
        password = self.txt_pass.get()

        if username == "" or password == "":
            messagebox.showerror("Error", "Please provide your both username and password", parent=self.root)
        else:
            query = 'select * from login_details where username=%s and password=%s'
            l = model.logindetails.LoginDetails(username, password)
            values = (l.get_username(), l.get_password())
            row = self.db.selectone(query, values)
            if row == None:
                messagebox.showerror('Error', 'Please Register First')
            else:
                messagebox.showinfo("Welcome", "Redirecting to Dashboard", parent=self.root)
                self.root.destroy()
                root = Tk()
                frontend.MainDashboard.MainDashboard(root)

    def reset_button(self):
        """
        This method resets Entry Fields
        :return:
        """
        self.txt_user.delete(0, END)
        self.txt_user.insert(0, "")

        self.txt_user.delete(0, END)
        self.txt_pass.insert(0, "")

    def register_button(self):
        """
        This method opens Register Window at the top of this login window
        :return:
        """
        root = Toplevel()
        frontend.register.RegisterPage(root)

# root = Tk()
# obj = Login(root)
# root.mainloop()
