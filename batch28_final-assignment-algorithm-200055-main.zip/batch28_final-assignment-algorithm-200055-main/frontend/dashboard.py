from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import backend.dbconnect
import model.studentdetails
import model.search
import model.sort


class Dashboard:
    """
    This class creates window for admin dashboard
    """

    def __init__(self, root):
        self.root = root
        self.root.title("Student Entry Dashboard")
        self.root.geometry("1250x710+120+0")
        self.root.resizable(False, False)
        self.root.config(bg="white")
        self.root.iconbitmap('E:\Softwarica\SEM 2\Introduction to algorithm\CW\submission\images\logo.ico')
        # self.bg = ImageTk.PhotoImage(file="E:\Softwarica\SEM 2\Introduction to algorithm\CW\submission\images\maindashboard.png")
        # self.bg_image = Label(self.root, image=self.bg).place(x=0, y=0, relheight=1, relwidth=1)

        self.db = backend.dbconnect.DBconnect()

        title_name = Label(root, text="Admin Dashboard", font=("Imapct", 35, "bold"), fg="#d77337", bg="white").pack(
            side=TOP)

        # Variables
        self.id = StringVar()
        self.name = StringVar()
        self.email = StringVar()
        self.gender = StringVar()
        self.contact = StringVar()
        self.dob = StringVar()

        self.search_var = StringVar()
        self.txt_search_var = StringVar()

        # MANAGE STUDENT FRAME
        managestd_frame = Frame(self.root, bg="#d77337", bd=2, relief=RIDGE)
        managestd_frame.place(x=5, y=50, width=450, height=560)

        m_title = Label(managestd_frame, text="Manage Student", font=("Goudy old style", 30, "bold"), bg="#d77337",
                        fg="white")
        m_title.grid(row=0, columnspan=2, padx=80)

        id_std_lbl = Label(managestd_frame, text="Student ID",
                           font=("Goudy old style", 20, "bold"), bg="#d77337", fg="white")
        id_std_lbl.grid(row=1, column=0, sticky="w", padx=0, pady=10)

        name_std_lbl = Label(managestd_frame, text="Name", font=("Goudy old style", 20, "bold"),
                             bg="#d77337",
                             fg="white")
        name_std_lbl.grid(row=2, column=0, sticky="w", padx=0, pady=10)

        email_std_lbl = Label(managestd_frame, text="Email",
                              font=("Goudy old style", 20, "bold"), bg="#d77337",
                              fg="white")
        email_std_lbl.grid(row=3, column=0, sticky="w", padx=0, pady=10)

        gender_std_lbl = Label(managestd_frame, text="Gender",
                               font=("Goudy old style", 20, "bold"), bg="#d77337",
                               fg="white")
        gender_std_lbl.grid(row=4, column=0, sticky="w", padx=0, pady=10)

        contact_std_lbl = Label(managestd_frame, text="Contact",
                                font=("Goudy old style", 20, "bold"), bg="#d77337",
                                fg="white")
        contact_std_lbl.grid(row=5, column=0, sticky="w", padx=0, pady=10)

        dob_std_lbl = Label(managestd_frame, text="DOB", font=("Goudy old style", 20, "bold"),
                            bg="#d77337",
                            fg="white")
        dob_std_lbl.grid(row=6, column=0, sticky="w", padx=0, pady=10)

        address_std_lbl = Label(managestd_frame, text="Address",
                                font=("Goudy old style", 20, "bold"), bg="#d77337",
                                fg="white")
        address_std_lbl.grid(row=7, column=0, sticky="w", padx=0, pady=10)

        # self.txt_id_std = Entry(managestd_frame, textvariable=self.id, font=("Times new roman", 15), bg="lightgray",
        #                         width=25)
        # self.txt_id_std.grid(row=1, column=1, sticky="w", padx=0, pady=10)

        self.txt_id_std = ttk.Combobox(managestd_frame, textvariable=self.id, font=("Times new roman", 15),
                                       width=24, state='readonly')
        query = 'select id from login_details'
        row = self.db.selectall(query)
        self.txt_id_std['values'] = (row)
        self.txt_id_std.grid(row=1, column=1, sticky="w", padx=0, pady=10)

        self.txt_name_std = Entry(managestd_frame, textvariable=self.name, font=("Times new roman", 15), bg="lightgray",
                                  width=25)
        self.txt_name_std.grid(row=2, column=1, sticky="w", padx=0, pady=10)

        self.txt_email_std = Entry(managestd_frame, textvariable=self.email, font=("Times new roman", 15),
                                   bg="lightgray", width=25)
        self.txt_email_std.grid(row=3, column=1, sticky="w", padx=0, pady=10)

        self.gender_std = ttk.Combobox(managestd_frame, textvariable=self.gender, font=("Times new roman", 15),
                                       width=24, state='readonly')
        self.gender_std['values'] = ('Male', 'Female', 'Other')
        self.gender_std.grid(row=4, column=1, sticky="w", padx=0, pady=10)

        self.txt_contact_std = Entry(managestd_frame, textvariable=self.contact, font=("Times new roman", 15),
                                     bg="lightgray", width=25)
        self.txt_contact_std.grid(row=5, column=1, sticky="w", padx=0, pady=10)

        self.txt_dob_std = Entry(managestd_frame, textvariable=self.dob, font=("Times new roman", 15), bg="lightgray",
                                 width=25)
        self.txt_dob_std.grid(row=6, column=1, sticky="w", padx=0, pady=10)

        self.txt_address_std = Text(managestd_frame, font=("Times new roman", 15), bg="lightgray", width=25, height=4)
        self.txt_address_std.grid(row=7, column=1, sticky="w", padx=0, pady=20)

        # DETAIL STUDENT FRAME

        detailstd_frame = Frame(self.root, bg="#d77337", bd=2, relief=RIDGE)
        detailstd_frame.place(x=470, y=50, width=770, height=560)

        self.sort = Button(detailstd_frame, text="Sort", command=self.sort, bg="white", fg="#d77337",
                           font=("Imapct", 18), width=10)
        self.sort.grid(row=0, column=2, columnspan=1, sticky="w", padx=10, pady=10)

        self.txt_search = Entry(detailstd_frame, textvariable=self.txt_search_var, font=("Times new roman", 15),
                                bg="lightgray", width=25)
        self.txt_search.grid(row=0, column=0, sticky="w", padx=10, pady=10)

        self.search_btn = Button(detailstd_frame, text="Search", command=self.search_button, bg="white", fg="#d77337",
                                 font=("Imapct", 18),
                                 width=10).grid(row=0, column=1, padx=10, pady=10)
        self.showall_btn = Button(detailstd_frame, text="Show All", bg="white", fg="#d77337", command=self.showintable,
                                  font=("Imapct", 18),
                                  width=9).grid(row=0, column=4, padx=10, pady=10)

        # -------------------------Table Frame-------------------------------------------------------------------------
        tbl_frame = Frame(detailstd_frame, bg="lightgray", bd=2, relief=RIDGE)
        tbl_frame.place(x=10, y=70, width=750, height=480)

        scroll_x = Scrollbar(tbl_frame, orient=HORIZONTAL)
        scroll_y = Scrollbar(tbl_frame, orient=VERTICAL)
        self.student_table = ttk.Treeview(tbl_frame,
                                          columns=("ID", "name", "email", "gender", "contact", "dob", "address"),
                                          xscrollcommand=scroll_x.set, yscrollcommand=scroll_y.set)
        scroll_x.pack(side=BOTTOM, fill=X)
        scroll_y.pack(side=RIGHT, fill=Y)
        scroll_x.config(command=self.student_table.xview)
        scroll_y.config(command=self.student_table.yview)
        self.student_table.heading("ID", text="ID")
        self.student_table.heading("name", text="Name")
        self.student_table.heading("email", text="Email")
        self.student_table.heading("gender", text="Gender")
        self.student_table.heading("contact", text="Contact")
        self.student_table.heading("dob", text="D.O.B")
        self.student_table.heading("address", text="Address")
        self.student_table['show'] = 'headings'
        self.student_table.column('ID', width=100)
        self.student_table.column('name', width=100)
        self.student_table.column('email', width=100)
        self.student_table.column('gender', width=100)
        self.student_table.column('contact', width=100)
        self.student_table.column('dob', width=100)
        self.student_table.column('address', width=150)
        self.student_table.pack(fill=BOTH, expand=1)
        self.student_table.bind("<ButtonRelease-1>", self.clickandfetch)
        # ------------------------- Button Frame -------------------------------
        btn_frame = Frame(self.root, bg="#d77337", bd=2, relief=RIDGE)
        btn_frame.place(x=5, y=620, width=450, height=80)

        add_btn = Button(btn_frame, text="Add", bg="white", fg="#d77337", font=("Imapct", 18), width=5,
                         command=self.add_button).grid(row=0, column=0, padx=15, pady=10)
        update_btn = Button(btn_frame, text="Update", bg="white", fg="#d77337", font=("Imapct", 18), width=5,
                            command=self.update_button).grid(row=0, column=2, padx=15, pady=10)
        delete_btn = Button(btn_frame, text="Delete", bg="white", fg="#d77337", font=("Imapct", 18), width=5,
                            command=self.delete_button).grid(row=0, column=3, padx=15, pady=10)
        clear_btn = Button(btn_frame, text="Clear", bg="white", fg="#d77337", font=("Imapct", 18), width=5,
                           command=self.clear_button).grid(row=0, column=4, padx=15, pady=10)

    def add_button(self):
        """
        This method adds information into database
        :return:
        """
        id = self.txt_id_std.get()
        name = self.txt_name_std.get()
        email = self.txt_email_std.get()
        gender = self.gender_std.get()
        contact = self.txt_contact_std.get()
        dob = self.txt_dob_std.get()
        address = self.txt_address_std.get("1.0", END)

        if id == '' or name == '' or email == '' or contact == '':
            messagebox.showerror('Error', 'Fill Empty Regions',parent=self.root)
            return
        else:
            s = model.studentdetails.Student(id, name, email, gender, contact, dob, address)
            query = 'insert into tbl_student(id,name,email,gender,contact,dob,address) values(%s,%s,%s,%s,%s,%s,%s)'
            values = (
                s.get_id(), s.get_name(), s.get_email(), s.get_gender(), s.get_contact(), s.get_dob(), s.get_address())
            self.db.insert(query, values)
            messagebox.showinfo('Success', 'Student Information Added Successfully',parent=self.root)
            self.showintable()

    def update_button(self):
        """
        This method updates infromation into database
        :return:
        """
        id = self.txt_id_std.get()
        name = self.txt_name_std.get()
        email = self.txt_email_std.get()
        gender = self.gender_std.get()
        contact = self.txt_contact_std.get()
        dob = self.txt_dob_std.get()
        address = self.txt_address_std.get("1.0", END)

        s = model.studentdetails.Student(id, name, email, gender, contact, dob, address)

        query = 'update tbl_student set ID =%s,name=%s,email=%s,gender=%s,contact=%s,dob=%s,address=%s where ID=%s'
        values = (
            s.get_id(), s.get_name(), s.get_email(), s.get_gender(), s.get_contact(), s.get_dob(), s.get_address(),
            s.get_id())
        self.db.update(query, values)
        messagebox.showinfo('Success', 'Student Information Updated',parent=self.root)
        self.showintable()

    def delete_button(self):
        """
        This method deletes information from database
        :return:
        """
        id = self.txt_id_std.get()
        name = self.txt_name_std.get()
        email = self.txt_email_std.get()
        gender = self.gender_std.get()
        contact = self.txt_contact_std.get()
        dob = self.txt_dob_std.get()
        address = self.txt_address_std.get("1.0", END)

        s = model.studentdetails.Student(id, name, email, gender, contact, dob, address)
        query = 'delete from tbl_student where ID= %s'
        values = (s.get_id(),)
        messagebox.askyesnocancel('Alert', 'Are you sure about deleting this data?',parent=self.root)
        self.db.delete(query, values)
        messagebox.showinfo('Success', 'Student Information Deleted',parent=self.root)

    def clear_button(self):
        """
        It clears all the entry field
        :return:
        """
        self.id.set("")
        self.name.set("")
        self.email.set("")
        self.gender.set("")
        self.contact.set("")
        self.dob.set("")
        self.txt_address_std.delete("1.0", END)

    def showintable(self):
        """
        This method displays information from the database into the table
        :return:
        """
        str = 'select * from tbl_student'
        rows = self.db.selectall(str)
        if len(rows) != 0:
            self.student_table.delete(*self.student_table.get_children())
            for row in rows:
                self.student_table.insert('', END, values=row)

    def clickandfetch(self, eventhandling):
        """
        This method displays the clicked row from table into the entry box
        :param eventhandling:
        :return:
        """
        cursor_row = self.student_table.focus()
        contents = self.student_table.item(cursor_row)
        row = contents['values']
        if len(row) != 0:
            self.id.set(row[0])
            self.name.set(row[1])
            self.email.set(row[2])
            self.gender.set(row[3])
            self.contact.set(row[4])
            self.dob.set(row[5])
            self.txt_address_std.delete("1.0", END)
            self.txt_address_std.insert(END, row[6])

    def search_button(self):
        """
        This method uses linear search algorithm to display searched items into the table
        :return:
        """
        str = "select * from tbl_student"
        rows = self.db.selectall(str)
        doSearch = self.txt_search_var.get()
        s = model.search.search().linearsearch(doSearch, rows)
        if s != False:
            self.student_table.delete(*self.student_table.get_children())
            self.student_table.insert("", END, values=rows[s])

    def sort(self):
        """
        This method uses insertion sort algorithm to sort the table according to the column name
        :return:
        """
        index = 1
        query = "select * from tbl_student"
        row = self.db.selectall(query)
        try:
            sorted_record = model.sort.sorting().insertion_sort(row, index)
            self.student_table.delete(*self.student_table.get_children())
            for i in sorted_record:
                self.student_table.insert("", END, values=i)
        except:
            messagebox.showerror("Error", "Error", parent=self.root)

# root = Tk()
# obj = Dashboard(root)
# root.mainloop()
