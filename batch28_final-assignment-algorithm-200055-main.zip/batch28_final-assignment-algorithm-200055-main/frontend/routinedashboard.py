from tkinter import *
from PIL import ImageTk
from tkinter import messagebox
import backend.dbconnect
from tkinter import ttk


class RoutineDashboard:
    """
    This creates the Window for routine dashboard
    """
    def __init__(self, root):
        self.root = root
        self.root.title('Routine Manager')
        self.root.geometry("1200x848+120+0")
        self.root.resizable(False, False)
        self.root.config(bg="white")
        self.root.iconbitmap('E:\Softwarica\SEM 2\Introduction to algorithm\CW\submission\images\logo.ico')

        self.bg = ImageTk.PhotoImage(file="E:\Softwarica\SEM 2\Introduction to algorithm\CW\submission\images\managerroutine.png")
        self.bg_image = Label(self.root, image=self.bg)
        self.bg.image = self.bg
        self.bg_image.place(x=0, y=0, relheight=1, relwidth=1)
        self.db = backend.dbconnect.DBconnect()

        # Variables
        self.sundaybreak_var = StringVar()
        self.sundaylunch_var = StringVar()
        self.sundaydinner_var = StringVar()
        self.sundaysnack_var = StringVar()

        self.mondaybreak_var = StringVar()
        self.mondaylunch_var = StringVar()
        self.mondaydinner_var = StringVar()
        self.mondaysnack_var = StringVar()

        self.tuesdaybreak_var = StringVar()
        self.tuesdaylunch_var = StringVar()
        self.tuesdaydinner_var = StringVar()
        self.tuesdaysnack_var = StringVar()

        self.wednesdaybreak_var = StringVar()
        self.wednesdaylunch_var = StringVar()
        self.wednesdaydinner_var = StringVar()
        self.wednesdaysnack_var = StringVar()

        self.thursdaybreak_var = StringVar()
        self.thursdaylunch_var = StringVar()
        self.thursdaydinner_var = StringVar()
        self.thursdaysnack_var = StringVar()

        self.fridaybreak_var = StringVar()
        self.fridaylunch_var = StringVar()
        self.fridaydinner_var = StringVar()
        self.fridaysnack_var = StringVar()

        self.saturdaybreak_var = StringVar()
        self.saturdaylunch_var = StringVar()
        self.saturdaydinner_var = StringVar()
        self.saturdaysnack_var = StringVar()




# -------- Breakfast Entry -------------
        self.sundaybreak = Entry(self.root, bg="#fffcf8", fg="black",font='50',textvariable=self.sundaybreak_var)
        self.sundaybreak.place(x=126,y=210,width=135,height=82)

        self.mondaybreak = Entry(self.root, bg="#fffcf8", fg="black",font='50',textvariable=self.mondaybreak_var)
        self.mondaybreak.place(x=268,y=210,width=135,height=82)

        self.tuesdaybreak = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.tuesdaybreak_var)
        self.tuesdaybreak.place(x=410, y=210, width=135, height=82)

        self.wednesdaybreak = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.wednesdaybreak_var)
        self.wednesdaybreak.place(x=552, y=210, width=135, height=82)

        self.thursdaybreak = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.thursdaybreak_var)
        self.thursdaybreak.place(x=694, y=210, width=132, height=82)

        self.fridaybreak = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.fridaybreak_var)
        self.fridaybreak.place(x=836, y=210, width=132, height=82)

        self.saturdaybreak = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.saturdaybreak_var)
        self.saturdaybreak.place(x=978, y=210, width=132, height=82)


# ----------------- Lunch Entry -------------
        self.sundaylunch = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.sundaylunch_var)
        self.sundaylunch.place(x=126, y=305, width=135, height=102)

        self.mondaylunch = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.mondaylunch_var)
        self.mondaylunch.place(x=268, y=305, width=135, height=102)

        self.tuesdaylunch = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.tuesdaylunch_var)
        self.tuesdaylunch.place(x=410, y=305, width=135, height=102)

        self.wednesdaylunch = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.wednesdaylunch_var)
        self.wednesdaylunch.place(x=552, y=305, width=135, height=102)

        self.thursdaylunch = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.thursdaylunch_var)
        self.thursdaylunch.place(x=694, y=305, width=132, height=102)

        self.fridaylunch = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.fridaylunch_var)
        self.fridaylunch.place(x=836, y=305, width=132, height=102)

        self.saturdaylunch = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.saturdaylunch_var)
        self.saturdaylunch.place(x=978, y=305, width=132, height=102)


# --------------- Dinner Entry -------------
        self.sundaydinner = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.sundaydinner_var)
        self.sundaydinner.place(x=126, y=420, width=135, height=102)

        self.mondaydinner = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.mondaydinner_var)
        self.mondaydinner.place(x=268, y=420, width=135, height=102)

        self.tuesdaydinner = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.tuesdaydinner_var)
        self.tuesdaydinner.place(x=410, y=420, width=135, height=102)

        self.wednesdaydinner = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.wednesdaydinner_var)
        self.wednesdaydinner.place(x=552, y=420, width=135, height=102)

        self.thursdaydinner = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.thursdaydinner_var)
        self.thursdaydinner.place(x=694, y=420, width=132, height=102)

        self.fridaydinner = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.fridaydinner_var)
        self.fridaydinner.place(x=836, y=420, width=132, height=102)

        self.saturdaydinner = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.saturdaydinner_var)
        self.saturdaydinner.place(x=978, y=420, width=132, height=102)


# ---------------- Snack Entry --------------
        self.sundaysnack = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.sundaysnack_var)
        self.sundaysnack.place(x=126, y=530, width=135, height=90)

        self.mondaysnack = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.mondaysnack_var)
        self.mondaysnack.place(x=268, y=530, width=135, height=90)

        self.tuesdaysnack = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.tuesdaysnack_var)
        self.tuesdaysnack.place(x=410, y=530, width=135, height=90)

        self.wednesdaysnack = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.wednesdaysnack_var)
        self.wednesdaysnack.place(x=552, y=530, width=135, height=90)

        self.thursdaysnack = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.thursdaysnack_var)
        self.thursdaysnack.place(x=694, y=530, width=132, height=90)

        self.fridaysnack = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.fridaysnack_var)
        self.fridaysnack.place(x=836, y=530, width=132, height=90)

        self.saturdaysnack = Entry(self.root, bg="#fffcf8", fg="black", font='50',textvariable=self.saturdaysnack_var)
        self.saturdaysnack.place(x=978, y=530, width=132, height=90)


# --------- Buttons -------------

        showRoutine = Button(self.root, text='Show Routine', bg="#E07e50", fg="white", font=("Imapct", 18),
                            command=self.showroutine)
        showRoutine.place(x=960, y=650, width=160, height=40)

        breakfastSet = Button(self.root,text='Set', bg="#E07e50", fg="white", font=("Imapct", 18),command=self.breakfastset)
        breakfastSet.place(x=1120,y=225,width=60,height=40)

        lunchSet = Button(self.root, text='Set', bg="#E07e50", fg="white", font=("Imapct", 18),
                              command=self.lunchset)
        lunchSet.place(x=1120, y=330, width=60, height=40)

        dinnerSet = Button(self.root, text='Set', bg="#E07e50", fg="white", font=("Imapct", 18),
                              command=self.dinnerset)
        dinnerSet.place(x=1120, y=450, width=60, height=40)

        snackSet = Button(self.root, text='Set', bg="#E07e50", fg="white", font=("Imapct", 18),
                              command=self.snackset)
        snackSet.place(x=1120, y=550, width=60, height=40)

        # ------------ Table Frame -----------------------------------
        frame_table = Frame(self.root, bg="lightgray", bd=2, relief=RIDGE)
        frame_table.place(x=120, y=660, width=800, height=150)

        self.table = ttk.Treeview(frame_table, columns=(
            "Type", "sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"))
        self.table.heading("Type", text="Type")
        self.table.heading("sunday", text="Sunday")
        self.table.heading("monday", text="Monday")
        self.table.heading("tuesday", text="Tuesday")
        self.table.heading("wednesday", text="Wednesday")
        self.table.heading("thursday", text="Thursday")
        self.table.heading("friday", text="Friday")
        self.table.heading("saturday", text="Saturday")
        self.table['show'] = 'headings'
        self.table.column("Type", width=90)
        self.table.column("sunday", width=90)
        self.table.column("monday", width=90)
        self.table.column("tuesday", width=90)
        self.table.column("wednesday", width=90)
        self.table.column("thursday", width=90)
        self.table.column("friday",width=90)
        self.table.column("saturday", width=90)
        self.table.pack(fill=BOTH, expand=1)
        self.table.bind("<ButtonRelease-1>", self.clickandfetch)

    def breakfastset(self):
        """
        This method updates Breakfast
        :return:
        """
        breaksunday = self.sundaybreak_var.get()
        breakmonday = self.mondaybreak_var.get()
        breaktuesday = self.tuesdaybreak_var.get()
        breakwednesday = self.wednesdaybreak_var.get()
        breakthursday = self.thursdaybreak_var.get()
        breakfriday = self.fridaybreak_var.get()
        breaksaturday = self.saturdaybreak_var.get()


        query = "update tbl_routine set sunday=%s ,monday=%s,tuesday=%s,wednesday=%s,thursday=%s,friday=%s,saturday=%s where Type='Breakfast'"
        values = (breaksunday,breakmonday,breaktuesday,breakwednesday,breakthursday,breakfriday,breaksaturday)

        self.db.update(query,values)
        messagebox.showinfo('Success','Breakfast Updated',parent=self.root)

    def lunchset(self):
        """
        This method updates Lunch
        :return:
        """
        lunchsunday = self.sundaylunch_var.get()
        lunchmonday = self.mondaylunch_var.get()
        lunchtuesday = self.tuesdaylunch_var.get()
        lunchwednesday = self.wednesdaylunch_var.get()
        lunchthursday = self.thursdaylunch_var.get()
        lunchfriday = self.fridaylunch_var.get()
        lunchsaturday = self.saturdaylunch_var.get()

        query = "update tbl_routine set sunday=%s ,monday=%s,tuesday=%s,wednesday=%s,thursday=%s,friday=%s,saturday=%s where Type='Lunch'"
        values = (lunchsunday, lunchmonday, lunchtuesday, lunchwednesday, lunchthursday, lunchfriday, lunchsaturday)

        self.db.update(query, values)
        messagebox.showinfo('Success', 'Lunch Updated',parent=self.root)

    def dinnerset(self):
        """
        This method updates Dinner
        :return:
        """
        dinnersunday = self.sundaydinner_var.get()
        dinnermonday = self.mondaydinner_var.get()
        dinnertuesday = self.tuesdaydinner_var.get()
        dinnerwednesday = self.wednesdaydinner_var.get()
        dinnerthursday = self.thursdaydinner_var.get()
        dinnerfriday = self.fridaydinner_var.get()
        dinnersaturday = self.saturdaydinner_var.get()

        query = "update tbl_routine set sunday=%s ,monday=%s,tuesday=%s,wednesday=%s,thursday=%s,friday=%s,saturday=%s where Type='Dinner'"
        values = (dinnersunday, dinnermonday, dinnertuesday, dinnerwednesday, dinnerthursday, dinnerfriday, dinnersaturday)

        self.db.update(query, values)
        messagebox.showinfo('Success', 'Dinner Updated',parent=self.root)


    def snackset(self):
        """
        This method updates snack
        :return:
        """
        snacksunday = self.sundaysnack_var.get()
        snackmonday = self.mondaysnack_var.get()
        snacktuesday = self.tuesdaysnack_var.get()
        snackwednesday = self.wednesdaysnack_var.get()
        snackthursday = self.thursdaysnack_var.get()
        snackfriday = self.fridaysnack_var.get()
        snacksaturday = self.saturdaysnack_var.get()

        query = "update tbl_routine set sunday=%s ,monday=%s,tuesday=%s,wednesday=%s,thursday=%s,friday=%s,saturday=%s where Type='Snack'"
        values = (snacksunday, snackmonday, snacktuesday, snackwednesday, snackthursday, snackfriday, snacksaturday)
        self.db.update(query, values)
        messagebox.showinfo('Success', 'Snack Updated',parent=self.root)


    def showroutine(self):
        """
        This method displays routine in the table
        :return:
        """
        query = 'select * from tbl_routine'
        rows = self.db.selectall(query)
        if len(rows) != 0:
            self.table.delete(*self.table.get_children())
            for row in rows:
                self.table.insert('', END, values=row)

    def clickandfetch(self, eventhandling):
        """
        This method displays the clicked row into entry box
        :param eventhandling:
        :return:
        """
        cursor_row = self.table.focus()
        contents = self.table.item(cursor_row)
        row = contents['values']
        if len(row) != 0:
            if row[0] == 'Breakfast':
                self.sundaybreak_var.set(row[1])
                self.mondaybreak_var.set(row[2])
                self.tuesdaybreak_var.set(row[3])
                self.wednesdaybreak_var.set(row[4])
                self.thursdaybreak_var.set(row[5])
                self.fridaybreak_var.set(row[6])
                self.saturdaybreak_var.set(row[7])

            if row[0] == 'Lunch':
                self.sundaylunch_var.set(row[1])
                self.mondaylunch_var.set(row[2])
                self.tuesdaylunch_var.set(row[3])
                self.wednesdaylunch_var.set(row[4])
                self.thursdaylunch_var.set(row[5])
                self.fridaylunch_var.set(row[6])
                self.saturdaylunch_var.set(row[7])

            if row[0] == 'Snack':
                self.sundaysnack_var.set(row[1])
                self.mondaysnack_var.set(row[2])
                self.tuesdaysnack_var.set(row[3])
                self.wednesdaysnack_var.set(row[4])
                self.thursdaysnack_var.set(row[5])
                self.fridaysnack_var.set(row[6])
                self.saturdaysnack_var.set(row[7])

            if row[0] == 'Dinner':
                self.sundaydinner_var.set(row[1])
                self.mondaydinner_var.set(row[2])
                self.tuesdaydinner_var.set(row[3])
                self.wednesdaydinner_var.set(row[4])
                self.thursdaydinner_var.set(row[5])
                self.fridaydinner_var.set(row[6])
                self.saturdaydinner_var.set(row[7])




# root = Tk()
# obj = RoutineDashboard(root)
# root.mainloop()
