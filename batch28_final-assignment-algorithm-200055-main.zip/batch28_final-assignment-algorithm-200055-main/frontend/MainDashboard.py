from tkinter import *
from PIL import ImageTk
from tkinter import messagebox
import frontend.dashboard
from frontend import routinedashboard

class MainDashboard:
    """
    This class Opens Main Dashboard Window
    """
    def __init__(self, root):
        self.root = root
        self.root.title("Dashboard")
        self.root.geometry("815x780+400+0")
        self.root.resizable(False, False)
        self.root.config(bg="white")
        self.root.iconbitmap('E:\Softwarica\SEM 2\Introduction to algorithm\CW\submission\images\logo.ico')

        self.bg = ImageTk.PhotoImage(file="E:\Softwarica\SEM 2\Introduction to algorithm\CW\submission\images\maindashboard.png")
        self.bg_image = Label(self.root, image=self.bg).place(x=0, y=0,relheight=1,relwidth=1)
        routine = ImageTk.PhotoImage(file='E:\Softwarica\SEM 2\Introduction to algorithm\CW\submission\images\schedule.png')
        student = ImageTk.PhotoImage(file='E:\Softwarica\SEM 2\Introduction to algorithm\CW\submission\images\student.png')
        exit= ImageTk.PhotoImage(file='E:\Softwarica\SEM 2\Introduction to algorithm\CW\submission\images\exit.png')

        routinemanagement = Button(self.root,image= routine,bd=0,bg="#eeeded",activebackground='#eeeded',command=self.routineDash)
        routinemanagement.image = routine
        routinemanagement.place(x=350,y=180)

        studentmanagement = Button(self.root, image=student,bd=0,bg="#eeeded",activebackground='#eeeded',command=self.stdDash)
        studentmanagement.image = student
        studentmanagement.place(x=350, y=470)

        exitbtn = Button(self.root, image=exit,bd=0,bg="#eeeded",activebackground='#eeeded',command=self.exit)
        exitbtn.image = exit
        exitbtn.place(x=570, y=600)

    def stdDash(self):
        """
        This method opens Student Management Dashboard
        :return:
        """
        messagebox.showinfo('Wait','Redirecting to Student Dashboard')
        root = Toplevel()
        frontend.dashboard.Dashboard(root)
    def exit(self):
        """
        This method closes the Dashboard Window
        :return:
        """
        messagebox.askyesnocancel('Alert','Are you sure you want to Exit?')
        self.root.destroy()

    def routineDash(self):
        """
        This method opens Routine Dashboard Window
        :return:
        """
        messagebox.showinfo('Wait', 'Redirecting to Routine Manager')
        root = Toplevel()
        routinedashboard.RoutineDashboard(root)

