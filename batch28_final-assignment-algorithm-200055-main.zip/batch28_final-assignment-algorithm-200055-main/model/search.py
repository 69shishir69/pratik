class search:
    """
    This is the class of linear search algorithm
    """
    def linearsearch(self,searchitem,source):
        for i in source:
            if searchitem in i:
                return int(source.index(i))
        return False