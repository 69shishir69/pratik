class LoginDetails:
    """
    It sets and gets value into login page using encapsulation
    """

    def __init__(self,username=None,password=None):
        self.__username = username
        self.__password = password

    def set_username(self,username):
        self.__username = username

    def get_username(self):
        return self.__username

    def set_password(self,password):
        self.__password = password

    def get_password(self):
        return self.__password

class RegisterDetails:
    """
    It sets and gets value into register page using encapsulation
    """
    def __init__(self,username=None,password=None,studentid=None):
        self.__username = username
        self.__password = password
        self.__studentid = studentid

    def set_username(self,username):
        self.__username = username

    def get_username(self):
        return self.__username

    def set_password(self,password):
        self.__password = password

    def get_password(self):
        return self.__password

    def set_studentid(self,studentid):
        self.__studentid = studentid

    def get_studentid(self):
        return self.__studentid