class sorting:
    """
    This is the class of insertion sort algorithm
    """
    def insertion_sort(self,list,indexes):
        for i in range(1,len(list)):
            save = list[i]
            j=i
            while j>0 and list[j-1][indexes] > save[indexes]:
                list[j] = list[j-1]
                j -= 1
            list[j] = save
        return list
