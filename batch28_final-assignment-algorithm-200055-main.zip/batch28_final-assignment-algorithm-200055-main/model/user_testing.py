import unittest
import backend.dbconnect
import model.search
import model.sort
import model.studentdetails
import model.logindetails


class Test_Database(unittest.TestCase):
    def setUp(self):
        """  set up the method for testing"""
        self.db = backend.dbconnect.DBconnect()
        self.a = model.search.search()
        self.b = model.sort.sorting()

    def test_fetch(self):
        """
        it test the fetch value of database
        """
        query = 'select * from tbl_student'
        a = self.db.selectall(query)
        print(a)
        self.assertEqual([('1', 'Prabin', 'prabin@gmail.com', 'Male', '9840238975', 'March 15,2000', 'Battisputali\n\n\n\n\n'), ('2', 'Amrit', 'duku.aryal@gmail.com', 'Male', '9855567895', 'Janurary, 2002', 'Maitidevi\n\n'), ('3', 'Shyam', 'shyam@gmail.com', 'Male', '982367855', 'June 24,1995', 'Sundarijal\n'), ('4', 'Santosh', 'sanosh@gmail.com', 'Male', '9878565331', 'July 26,1999', 'Kaushaltaar\n'), ('5', 'Abhinandan', 'abhinandan@gmail.com', 'Male', '9856753221', 'Feburary 14,1998', 'Ramechap\n'), ('6', 'TestPerson', 'sarman@gmail.com', 'Male', '9852064789', 'November 26,2000', 'Kalanki\n\n'), ('7', 'Mahesh', 'mahesh@gmail.com', 'Male', '9875642341', 'September 21,2000', 'Maitidevi\n'), ('85', 'test', 'test@123', 'Male', '980000000', 'Janurary 15,2000', 'test\n')]
, self.db.selectall(query))

    def test_searching(self):
            """
            it test the searching value
            """
            query = "select * from  tbl_student"
            a = self.db.selectall(query)
            print(a)
            b = self.a.linearsearch('Shyam', a)
            print(b)
            self.assertEqual(2, b)
    def test_sorting(self):
        """
        it test the sorting of database fetch value
        """
        query = "select * from  tbl_student"
        a = (self.db.selectall(query))
        b = self.b.insertion_sort(a,0)
        print(b)
        self.assertEqual(
            [('1', 'Prabin', 'prabin@gmail.com', 'Male', '9840238975', 'March 15,2000', 'Battisputali\n\n\n\n\n'), ('2', 'Amrit', 'duku.aryal@gmail.com', 'Male', '9855567895', 'Janurary, 2002', 'Maitidevi\n\n'), ('3', 'Shyam', 'shyam@gmail.com', 'Male', '982367855', 'June 24,1995', 'Sundarijal\n'), ('4', 'Santosh', 'sanosh@gmail.com', 'Male', '9878565331', 'July 26,1999', 'Kaushaltaar\n'), ('5', 'Abhinandan', 'abhinandan@gmail.com', 'Male', '9856753221', 'Feburary 14,1998', 'Ramechap\n'), ('6', 'TestPerson', 'sarman@gmail.com', 'Male', '9852064789', 'November 26,2000', 'Kalanki\n\n'), ('7', 'Mahesh', 'mahesh@gmail.com', 'Male', '9875642341', 'September 21,2000', 'Maitidevi\n'), ('85', 'test', 'test@123', 'Male', '980000000', 'Janurary 15,2000', 'test\n')]

            , b)
    def test_add(self):
        """
        it test the add method of database
        """
        query = "insert into  login_details(username,password,ID) values(%s,%s,%s)"
        u_name = str(input('Enter Username:'))
        passw = str(input("Enter Password: "))
        id = str(input("Enter ID:"))
        values =(u_name,passw,id)
        a=self.db.select(query,values)
        self.assertIsNot(False,a)
    def test_update(self):
        """
        it test the update function of database
        """
        u_name = str(input('Enter Username:'))
        passw = str(input("Enter Password: "))
        id = str(input("Enter ID:"))
        query = "update login_details set username=%s,password=%s where ID=%s"
        values = (u_name, passw, id)
        d=self.db.update(query,values)
        if d:
            print('succese')
        else:
            return False
        self.assertEqual(True, d)

    def test_del(self):
        """
        it test the delete value of database
        """
        id = str(input("Enter ID:"))
        values=(id,)
        query="delete from login_details where ID=%s"
        b=self.db.delete(query,values)
        if b:
            print('Success')
        else:
            return False
        self.assertEqual(True,b)
    def test_set_username_register(self):
        """
        it test the set get method of username
        """
        q=model.logindetails.RegisterDetails()
        username=str(input("Enter username: "))
        q.set_username(username)
        a=q.get_username()
        print(a)
        self.assertEqual(username,a)
    def test_set_studentID_student(self):
        """
        it test the set get method of student
        """
        q=model.studentdetails.Student()
        studentid=str(input("Enter the studentid: "))
        q.set_id(studentid)
        a=q.get_id()
        print(a)
        self.assertEqual(studentid,a)

    def test_getting_studentName_and_studentPassword_Login(self):
        """
        it test the set and get method of login
        """
        pe= model.logindetails.LoginDetails()
        username=str(input("Enter the student name: "))
        password = str(input("Enter the password: "))
        pe.set_username(username)
        pe.set_password(password)
        get_value= pe.get_username()
        get_value2=pe.get_password()
        self.assertEqual(get_value2,password),self.assertEqual(get_value,username)

    def test_getting_studentName_and_studentPassword_Register(self):
        """
        it test the set and get method of Register
        """
        pe = model.logindetails.RegisterDetails()
        username = str(input("Enter the student name: "))
        password = str(input("Enter the password: "))
        pe.set_username(username)
        pe.set_password(password)
        get_value = pe.get_username()
        get_value2 = pe.get_password()
        self.assertEqual(get_value2, password), self.assertEqual(get_value, username)
    def tearDown(self):
        """
        this method runs with setup method
        """
        del self.db
        del self.a
        del self.b


if __name__ == "__main__":
    obj = Test_Database()
