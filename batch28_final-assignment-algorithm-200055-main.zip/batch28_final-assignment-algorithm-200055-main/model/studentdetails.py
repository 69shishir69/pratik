class Student:
    """
    It sets and gets value into student dashboard encapsulation
    """
    def __init__(self, id=None, name=None, email=None, gender=None, contact=None, dob=None, address=None):
        self.__id = id
        self.__name = name
        self.__email = email
        self.__gender = gender
        self.__contact = contact
        self.__dob = dob
        self.__address = address

    def set_id(self, id):
        self.__id = id

    def get_id(self):
        return self.__id

    def set_name(self, name):
        self.__name = name

    def get_name(self):
        return self.__name

    def set_email(self, email):
        self.__email = email

    def get_email(self):
        return self.__email

    def set_gender(self, gender):
        self.__gender = gender

    def get_gender(self):
        return self.__gender

    def set_contact(self, contact):
        self.__contact = contact

    def get_contact(self):
        return self.__contact

    def set_dob(self, dob):
        self.__dob = dob

    def get_dob(self):
        return self.__dob

    def set__address(self, address):
        self.__address = address

    def get_address(self):
        return self.__address
