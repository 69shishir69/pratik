import mysql.connector


class DBconnect:
    '''
    Class to connect the GUI with database
    '''
    def __init__(self):
        self.con = mysql.connector.connect(host='localhost', user='root', password='deVprab@1', database='assignment')
        self.cur = self.con.cursor()

    def insert(self, query, values):
        self.cur.execute(query, values)
        self.con.commit()

    def update(self, query, values):
        self.cur.execute(query, values)
        self.con.commit()

    def select(self, query, values):
        self.cur.execute(query, values)
        rows = self.cur.fetchall()
        return rows

    def delete(self,query,values):
        self.cur.execute(query,values)
        self.con.commit()

    def selectall(self, str):
        self.cur.execute(str)
        rows = self.cur.fetchall()
        return rows
    def selectone(self,query,values):
        self.cur.execute(query,values)
        row = self.cur.fetchone()
        return row

