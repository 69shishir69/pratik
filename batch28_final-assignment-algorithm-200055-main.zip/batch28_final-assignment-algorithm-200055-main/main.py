import frontend.login
from tkinter import *

if __name__ == '__main__':
    root = Tk()
    frontend.login.Login(root)
    root.mainloop()
